/* Eric Li
A20419312
ITMD 411
Lab 2 */

public abstract class Client {
    public abstract void readData();
    public abstract void processData();
    public abstract void printData();
}